# plugins/alpha_warning.py
# -*- coding: utf-8 -*-

"""
alpha_warning – плагин‑модуль, отображающий окно‑предупреждение при
запуске xHelper α (версии 1.0.1 LTS/ATS).

Содержание окна:
    • Текст: «Эта программа – alpha‑версия, используйте на свой страх и риск.
      Хотите начать использование Alpha‑версии?»
    • Кнопка **«Да»** – закрывает предупреждение и продолжает работу.
    • Кнопка **«Нет»** – закрывает приложение (для тех, кто не хочет
      работать с нестабильной сборкой).
    • Кнопка **«Что это значит?»** – открывает второе окно‑помощник,
      где объясняется, что программа‑альфа может давать сбои, а также
      приводится краткий гайд по использованию xHelper и созданию плагинов.

Плагин не меняет ядро программы и использует только публичный API
`main_window` (логирование, закрытие окна, таймеры)."""

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton,
    QHBoxLayout, QTextEdit, QMessageBox,
)


# ----------------------------------------------------------------------
#   Текст справки (можно расширить при необходимости)
# ----------------------------------------------------------------------
HELP_TEXT = """
<h2>⚠️  Это Alpha‑версия</h2>
<p>
Программа <b>xHelper α (1.0.1 LTS/ATS)</b> находится в <i>альфа‑стадии</i>.
Это значит, что в ней могут присутствовать:
<ul>
<li>неотлаженные функции;</li>
<li>неожиданные падения (краши) при работе с ADB/fastboot;</li>
<li>некорректные ответы от устройства;</li>
<li>сбои UI, если одновременно запущено несколько тяжёлых операций.</li>
</ul>
Мы настоятельно рекомендуем использовать эту сборку <b>только в тестовых
целях</b> и <b>не</b> в критически важных проектах.
</p>

<hr>

<h2>📚 Краткий гайд по использованию xHelper (функционал описываеться без использования плагинов, что скорее всего невозможно, так как xHelper поставляеться с плагинами</h2>
<ol>
<li><b>Подключение устройства</b> – откройте вкладку <i>«Устройства»</i> и нажмите
«Обновить список устройств». Убедитесь, что ADB‑драйвер установлен.</li>

<li><b>Управление приложениями</b> – во вкладке <i>«APK»</i> можно установить,
удалить или запустить приложение, указав его пакет.</li>

<li><b>Массовая установка</b> – вкладка <i>«Массовая установка APK»</i> позволяет
выбрать папку с несколькими <code>.apk</code>‑файлами и установить их одной
командой.</li>

<li><b>Файловые операции</b> – во вкладке <i>«Файлы»</i> копируются файлы
на/с устройства (<code>adb push / pull</code>).</li>

<li><b>Тестирование приложений</b> – вкладка <i>«Тестирование приложений»</i>
запускает каждое приложение, собирает <code>logcat</code> и отмечает
приложения, которые упали.</li>

<li><b>Скринкаст и скриншоты</b> – во вкладке <i>«Экран устройства»</i>
можно запустить <code>scrcpy</code> (если он установлен) или сделать
скриншот.</li>

<li><b>Бэкапы</b> – вкладка <i>«Бэкап / Восстановление»</i> создаёт
полный ADB‑бэкап и позволяет восстановить его.</li>
</ol>

<hr>

<h2>🔧 Как писать собственные плагины для xHelper</h2>
<p>Плагин – это обычный <b>Python‑модуль</b>, помещённый в каталог <code>plugins/</code>
рядом с <code>main.py</code>.  При старте программы <code>XHelperMainWindow.load_plugins()</code>
автоматически импортирует каждый файл <code>*.py</code>, ищет в нём функцию
<code>register(main_window)</code> и вызывает её, передавая объект главного окна.</p>

<p>Минимальный шаблон плагина:</p>

<pre><code># plugins/example.py
# -*- coding: utf-8 -*-

def register(main_window):
    from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout
    tab = QWidget()
    layout = QVBoxLayout(tab)
    layout.addWidget(QLabel("Пример плагина"))
    main_window.tabs.addTab(tab, "Example")
</code></pre>

<p>Внутри <code>register</code> вы имеете доступ к:</p>
<ul>
<li><code>main_window.run_adb_command(...)</code> – выполнить любую ADB‑команду.</li>
<li><code>main_window.log_message(...)</code> – писать в правый консоль‑лог.</li>
<li><code>main_window.tabs</code> – добавить свои вкладки.</li>
<li><code>main_window.addDockWidget(...)</code> – добавить dock‑виджет.</li>
<li>и любые другие публичные атрибуты/методы <code>XHelperMainWindow</code>.</li>
</ul>

<p>Полезные советы:</p>
<ul>
<li>Не вызывайте длительные операции напрямую в UI‑слоте – используйте
<code>QThread</code> / <code>threading.Thread</code> и передавайте результаты
через сигналы (<code>main_window.log_signal.emit(...)</code>). </li>
<li>Если ваш плагин меняет тему/стили, используйте
<code>QApplication.instance().setPalette(...)</code>.</li>
<li>Для доступа к настройкам используйте <code>main_window.settings</code>
(словарь, сохраняемый в <code>~/.xhelper_prealpha_config.json</code>).</li>
</ul>

<hr>

<p>Если появятся вопросы – создавайте <i>Issue</i> в репозитории плагина
или пишите в чат‑поддержку проекта (если они вообще будут созданы).</p>
"""


# ----------------------------------------------------------------------
#   Первое (модальное) окно – предупреждение Alpha‑версии
# ----------------------------------------------------------------------
def _show_alpha_warning(main_window):
    """Показывает диалог‑предупреждение сразу после запуска main_window."""
    dialog = QDialog(main_window)
    dialog.setWindowTitle("Alpha‑версия xHelper")
    dialog.setModal(True)
    dialog.resize(460, 200)

    layout = QVBoxLayout(dialog)

    # Текстовое сообщение
    msg = QLabel(
        "Эта программа – <b>alpha‑версия</b>. "
        "Используйте её на свой страх и риск.<br><br>"
        "Хотите начать использование Alpha‑версии?"
    )
    msg.setWordWrap(True)
    layout.addWidget(msg)

    # Кнопки
    btn_layout = QHBoxLayout()
    btn_yes = QPushButton("Да")
    btn_no = QPushButton("Нет")
    btn_what = QPushButton("Что это значит?")
    btn_layout.addWidget(btn_yes)
    btn_layout.addWidget(btn_no)
    btn_layout.addStretch()
    btn_layout.addWidget(btn_what)
    layout.addLayout(btn_layout)

    # --------------------------------------------------------------
    #   Обработчики кнопок
    # --------------------------------------------------------------
    def _accept():
        # Пользователь согласился – просто закрываем окно.
        dialog.accept()

    def _reject():
        # Пользователь отказался – закрываем главное окно программы.
        reply = QMessageBox.question(
            dialog,
            "Выход",
            "Вы действительно хотите закрыть программу?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            main_window.close()      # произвольное закрытие
        else:
            # Если пользователь передумал – оставляем окно открытым.
            return

    def _show_details():
        """Открывает второе окно с подробным описанием и гайдом."""
        details = QDialog(dialog)
        details.setWindowTitle("Что значит «Alpha‑версия»")
        details.resize(560, 620)

        d_layout = QVBoxLayout(details)

        # Текстовое поле (read‑only) – позволяет копировать при необходимости
        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setHtml(HELP_TEXT)       # HTML‑разметка для красоты
        d_layout.addWidget(txt)

        # Кнопка «Закрыть»
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(details.accept)
        d_layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)

        details.exec()                # модальное окно

    # Привязываем сигналы
    btn_yes.clicked.connect(_accept)
    btn_no.clicked.connect(_reject)
    btn_what.clicked.connect(_show_details)

    # Показ диалога
    dialog.exec()


# ----------------------------------------------------------------------
#   Регистрация плагина
# ----------------------------------------------------------------------
def register(main_window):
    """
    При загрузке плагина ставим таймер «singleShot», чтобы показать
    предупреждение после того, как главное окно полностью построится.
    """
    # Запускаем через <<0>> мсек, чтобы гарантировать, что UI уже готов.
    QTimer.singleShot(0, lambda: _show_alpha_warning(main_window))

    # Информируем в лог, что плагин активирован
    main_window.log_message("[Alpha‑Warning] Плагин загружен – показ предупреждения о версии.")
